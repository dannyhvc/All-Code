/**
file path: C:\Users\DaniS\source\repos\CLASS CODE\Project0\numbers.c
Author: Daniel Herrera-Vazquez 0881570 for section 03
Prof: Trihn Han
Purpose: this program is to determine properties of a number depending on the input given via the user.
date (last edit): feb 1, 2019.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

/*
Method name: input
Purpose:
Return Value:
Parameters:
date (last edit):
*/
int input()
{
	char c;
	int * arr;
	while (c = scanf("%d", &arr))
	{
	}

	return 0;
}


/*
Method name: main()
Purpose: key to running the program.
Return Value: EXIT_SUCCESS
Parameters: nothing
date (last edit):
*/
int main()
{
	//welcome input 
	printf("Newcomb-Benford Stats (v2.0.0), �2018-2019 Daniel Herrera\n");
	printf("=========================================================\n");
	printf("Enter white-space separated real numbers. Terminate input with ^Z\n");

	int * inputArr;
	int size;
	inputArr = (int *)malloc(size * sizeof(int));



	return EXIT_SUCCESS;
}//end main()

/*
Method name: 
Purpose: 
Return Value: 
Parameters: 
date (last edit): 
*/