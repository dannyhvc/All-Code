﻿/**
file path: C:\Users\DaniS\source\repos\CLASS CODE\Project0\numbers.c
Author: Daniel Herrera-Vazquez 0881570 for section 03
Prof: Trihn Han
Purpose: this program is to determine properties of a number depending on the input given via the user.
date (last edit): feb 1, 2019.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <stdbool.h>


/*
Method name: toPositive
Purpose: helper function used to turn negative numbers to positive.
Return Value: positive integer.
Parameters: integer num from input.
date (last edit): feb 1, 2019
*/
int toPositive(int num)
{
	if (num < 0)
		return num *= -1;
	else
		return num;
}//end toPositive()


/*
Method name: getNumber()
Purpose: Looks through individual chars in the console and determines converts it to a deciaml number
Return Value: int --> returns a the integer value in base 10 decimal.
accpets: void --> no perameter
date (last edit): feb 1, 2019
*/
int getNumber()
{
	
	size_t input_char;// converts to the most appropriate type for int -> char conversion.
	int accumulator = 0;
	int sign = 1;

	while (((input_char = getchar()) != '\n') || ((input_char = getchar()) != EOF))
	{
		if (input_char == '\n' && !isdigit(input_char)) //checks to see if the input is a digit
		{									
			break;// closes the program if not a digit
		}//end if

		if (input_char != '-' && !isdigit(input_char))
		{
			puts("Error 422: Invalid input.");
			exit(0);
		}//end if

		//changes the sign depending if a "-" is inputed as a char.
		if (input_char == '-')
		{
			sign = -1;
		}
		else
		{
			accumulator = (accumulator * 10) + (input_char - '0'); // converts the char to a deciaml number and adds it to the accumulator
		}//end if-else
	}//end while

	return accumulator *= sign;

}//end getNumber()


/*
Method name: rPrints
Purpose:
Return Value: converts the number from decimal input to char output
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void RPrints(int num)
{
	char output;

	if (num == 0)
		return;

	//outputs number to screen
	int mod = num % 10;
	RPrints(num / 10);
	output = mod + '0';

	//prints the output to screen.
	putchar(output);

}//end prints()


/*
Method name:
Purpose: checks the sign of the number before printing it.
Return Value: void
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void Prints(int num)
{
	int sign = 1;

	if (num == 0)
		putchar('0');
	if (num < 0)
	{
		putchar('-');
		num *= -1;
	}
	
	RPrints(num);
}


/*
Method name: domain()
Purpose: shows the in which set of real whole numbers the input is in.
Return Value: void
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void domain(int num)
{
	if (num < 0)
		puts("\nThe number is a integer number.");
	else
		puts("\nThe number is a natural number.");	
}//end domain()


/*
Method name: pairity()
Purpose: checks if the number is odd or even using modulous.
Return Value: void
Parameters: int num --> the input from getNumber()
date (last edit): feb 1, 2019
*/
void pairity(int num)
{
	if (num % 2 == 0)
		puts("The number is even.");
	else
		puts("The number is odd.");
}//end pairity()


/*
Method name: isPrime()
Purpose: check if the number if divisible by any other number.
		 ie. if the number prime or composite.
Return Value:
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void isPrime(int num)
{
	//declaring variables
	bool flag = true;

	//turns the number into a positive for process use.
	num = toPositive(num);

	//LCC starts at 2 and ends less than
	//the number, to act as fence posts.
	for (int i = 2; i < num; ++i)
	{
		if ((num % i) == 0)
		{
			flag = false;
			break;
		}
		else
			flag = true;
	}//end for

	//output condition
	if (flag == true)
		puts("The number is Prime.");
	else
		puts("The number is composite.");
}//end isPrime()


/*
Method name: isTraingular()
Purpose: checks if the input is a pascals triangular number.
Return Value: void
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void isTraingular(int num)
{
	//turns the number to a positive
	num = toPositive(num);

	//equations to find wheather a number is within 
	//the zero of the equation 0 = n(n+1) - 2k, where k = c(c+1) / 2.
	double a = (sqrt(1 + 8 * num) - 1) / 2;
	double b = (int) (sqrt(1 + 8 * num) - 1) / 2;

	//condition to say wheather the number is
	if ((a / b) == 1.0)
		puts("The number is triangular.");
	else
		puts("The number is not triangular.");
}//end traingular()


/*
Method name: isSquare()
Purpose: Checks if the number is square number using the root function.
Return Value: void, prints output using puts.
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void isSquare(int num)
{
	//if the truncated root version is equal to the 
	//root then the output will yeild true.
	if ((sqrt(num) - floor(sqrt(num))) == 0)
		puts("The number is square.");
	else
		puts("The number is not square.");
}//end isSquare()


/*
Method name: isFactorial()
Purpose: Checks if the input is a factorial number.
Return Value: void
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void isFactorial(int num)
{
	//declaring and initializing variables.
	int fact = 1;
	int i = 1;

	//lCC to see if the factorial greater or equal to the 
	while (fact < num)
	{
		i++;
		fact *= i;
	}

	//output condition: checks if equal then the number is a factorial
	if (fact == num)
		puts("The number is a factorial.");
	else
		puts("The number is not a factorial.");
}//end isFactorial()


/*
Method name: isPerfDefAbun()
Purpose: Checks if the number is perfect, deffecient, or abundant
Return Value: void --> prints the output
Parameters: int num --> the input
date (last edit): feb 1, 2019
*/
void isPerfDefAbun(int num)
{
	//declaring variables
	int i = 1;
	int sum = 0;

	//loop to check where the number stands on the condition.
	while (i < num)
	{
		if (num % i == 0)
			sum += i;
		++i;
	}//end while

	//output condition.
	if (sum == num)
		puts("The number is perfect.");
	else if (sum > num)
		puts("The number is abundant.");
	else
		puts("The number is deffecient.");
}//end isPerfDefAbun()


/*
Method name: isPowOfTwo()
Purpose: void method that checks if the input values is a power of 2.
Return Value: void, prints using puts()
Parameters: integer input derived from getNumber()
date (last edit): feb 1, 2019
*/
void isPowOfTwo(int num)
{
	//using the log property where, logb(x) = log(x) / log(b).
	double a = log(num) / log(2);
	double b = floor(log(num) / log(2));

	//checking if the truncated log is equal to the non truncated one.
	if ((a - b) == 0)
		puts("The number is a power of two.");
	else
		puts("The number is not a power of two.");
}//end isPowOfTwo()


/*
Method name: main()
Purpose: runs the program
Return Value: return 0 on run success
Parameters: none
date (last edit): feb 1, 2019
*/
int main()
{
	//declaring variables
	int num;

	//input section.
	puts("Enter a number (press enter twice): "); 
	num = getNumber();

	//printing section
	puts("You entered...");
	Prints(num);

	//math property section
	domain(num);
	pairity(num);
	isTraingular(num);
	isPrime(num);
	isSquare(num);
	isFactorial(num);
	isPerfDefAbun(num);
	isPowOfTwo(num);

	//returns 0 on run success.
	return EXIT_SUCCESS;	
}//end main()
