/*
author: Daniel Herrera 0881570
*/
//commun libs to have
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int main()
{
	int * points;//interger pointer points to nothing.

	/*
	- pointer, points to a section of memory addresses allocated using the malloc function
	  therefore the heap finds open memory to be used for pointing to and the pointer can
	  look at the location of any specific part of it.
	*/
	points = (int *)malloc(5 * sizeof(int));
	
	


	free(points);

	return EXIT_SUCCESS;
}