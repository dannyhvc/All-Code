/*!	\file		array_t.c
	\author		Garth Santor
	\date		2019-01-24

	Array abstract data type.
*/

#include "array_t.h"
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

unsigned const DEFAULT_CAP = 8;
int const OK = 1;
int const FAIL = 0;

#ifdef _M_X64
void* const DBG_PTR = (void * const)0xcccccccccccccccc;
#else
void* const DBG_PTR = (void * const)0xcccccccc;
#endif // _M_X64

/*Make an empty array obj. */
array_t array()
{
	array_t arr = { NULL, 0, 0 };
	return arr;
}//end array()

/*! array_push_back apends an element to the end of the array without deleting any previous memory.
	More memory is allocated if needed.
*/
bool array_push_back(array_t* pArray, array_value_t value) 
{
	assert(pArray != DBG_PTR && pArray != NULL && "No array_t object");
	assert(pArray->data != DBG_PTR && "array_push_back: array has not been initialized.");
	assert(pArray->nSize <= pArray->nCapacity && "array size > array capacity - impossible");

	if (pArray ->nSize == pArray ->nCapacity)
	{
		size_t newCapacity = pArray->nCapacity * 2;
		if (newCapacity == 0) ++newCapacity;
			array_value_t* pNewBlock = realloc(pArray->data, newCapacity * sizeof(array_value_t));
		if (pNewBlock == NULL)
			return false;

		pArray->data = pNewBlock;
		pArray -> nCapacity = newCapacity;

	}

	pArray->data[pArray->nSize++] = value;
	return true;
}//end array_push_back()