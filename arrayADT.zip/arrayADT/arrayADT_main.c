/*!	\file		arrayADT_main.c
	\author		Garth Santor
	\date		2019-01-24

	Array abstract data type demonstrator.
*/
#include "array_t.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdint.h>


typedef uint64_t uint;


/*! Computer the number of digits in the integer. */
unsigned num_digits(unsigned long long number) {
	return (unsigned)floor(log10((double)number)) + 1;
}


/*! Computer the number of digits in the integer. */
uint roll(uint nSides) {
	return (uint)(floor(rand() / (RAND_MAX + 1.0)*nSides)) + 1;
}

int main() {

	//initialize the memory tracking system - debug only.
#if defined(_DEBUG)
	int dbgFlags = _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG); // what are your current settings.
	dbgFlags |= _CRTDBG_CHECK_ALWAYS_DF; //check block integrity on every memory call.
	dbgFlags |= _CRTDBG_DELAY_FREE_MEM_DF; //don;t remove vlock on delete.
	dbgFlags |= _CRTDBG_LEAK_CHECK_DF; // check for leaks at process termination.

	_CrtSetDbgFlag(dbgFlags);
#endif

	//malloc(42); //test for mem leaks.

	array_t myArray;


	// seed the random number generator
	srand((unsigned)time(NULL));


	printf("Enter the number of test rolls: ");
	uint nRolls = 1000;
	//scanf_s("%llu", &nRolls);
	putchar('\n');


	// roll the 2d6 die many times
	//uint rolls[1000];
	array_t rolls = array();
	for (uint i = 0; i < nRolls; ++i)
		array_push_back(&rolls, roll(6) + roll(6));
		//rolls[i] = roll(6) + roll(6);


	//// count the frequencies
	//uint counts[13] = { 0 };
	//for (uint i = 0; i < nRolls; ++i) {
	//	counts[rolls[i]]++;
	//}


	//// print the frequencies
	//unsigned maxDigits = num_digits(counts[7]);
	//for (uint i = 2; i <= 12; ++i) {
	//	double percentage = counts[i] / (double)nRolls * 100.0;
	//	printf("[%2llu] = %*llu: %8.3lf\n", i, maxDigits, counts[i], percentage);
	//}

	return EXIT_SUCCESS;
}