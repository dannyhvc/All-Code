/*!	\file		array_t.h
	\author		Garth Santor
	\date		2019-01-24

	Array abstract data type.
	*/

#define _CRT_DEBUG_MAP_ALLOC
#include <crtdbg.h> // CRT = C - RUNTIME, dbg = debug
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

typedef uint64_t array_value_t;

typedef struct array_t_tag
{
	array_value_t*	data;
	size_t			nSize;
	size_t			nCapacity;	
}array_t;

array_t array();
bool array_push_back(array_t* pArray, array_value_t value);